Para más información de cómo instalar librerías, mire: http://www.arduino.cc/en/Guide/Libraries
